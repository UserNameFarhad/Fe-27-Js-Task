import React from 'react'
import './Description.css'
const Description = () => {
  return (
    <div className='description'>
        <button>Description</button>
        <button>Reviews(122)</button>
        <div className="description-para">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt magni maxime consequatur perferendis neque consectetur dolor? Dolores quo laborum veniam accusantium deleniti sit, error voluptates? Pariatur repellendus soluta quibusdam harum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa eum eius sit quis ipsa nam veniam minima, accusamus saepe voluptates molestias natus placeat distinctio, tenetur voluptatem! Quis quibusdam voluptatum quas?</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa eum eius sit quis ipsa nam veniam minima, accusamus saepe voluptates molestias natus placeat distinctio, tenetur voluptatem! Quis quibusdam voluptatum quas?</p>
        </div>
      <p></p>
    </div>
  )
}

export default Description
