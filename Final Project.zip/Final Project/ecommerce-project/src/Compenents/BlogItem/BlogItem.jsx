import React from 'react'
import './BlogItem.css'
import calender from '../Assets/calendar.png'
const BlogItem = ({name,image,date}) => {
  return (
    <div className='BlogItem'>
      <div className="blog-cards">
        <img src={image} className='blog-img' alt="" />
        <div className="info">
            <span>
                <img src={calender} alt="" />
                <h4>{date}</h4>
            </span>
            <h2>{name}</h2>
            <a href="#">READ MORE</a>
        </div>
      </div>
    </div>
  )
}

export default BlogItem
