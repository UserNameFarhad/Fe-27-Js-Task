import React, { useContext } from "react";
import "./CartItems.css";
import { ShopContext } from "../../Context/Context";
import close_dark from "../Assets/darkClose.png";
import lightClose from '../Assets/close.png'
const CartItems = ({mode}) => {
  const { all_product, cartItem, removeFromCart } = useContext(ShopContext);
  return (
    <div className='cartItems'>
      <div className='cartitems-format-main'>
        <p>Products</p>
        <p>Title</p>
        <p>Price</p>
        <p>Quantity</p>
        <p>Total</p>
        <p>Remove</p>
      </div>
      <hr />
     
      {all_product.map((e)=>{
        if(cartItem[e.id]>0){
            return  <div>
            <div className='cartitems-format'>
              <img className="proImg" src={e.image} alt='' />
              <p>{e.name}</p>
              <p>${e.newPrice}</p>
              <button className='count'>{cartItem[e.id]}</button>
              <p>${e.newPrice*cartItem[e.id]}</p>
              <img src={mode ==="light"?close_dark:lightClose} className="closed" onClick={()=>{removeFromCart(e.id)}} alt='' />
            </div>
            <hr />
            </div>
        }
        return null;
      })}

      <div className="cart-total">
        <div className="total">
          <span>
            <h5>Subtotal</h5>
            <h5>{0}$</h5>
          </span>
          <hr />
          <span>
            <h5>Shipping Free</h5>
            <h5>Free</h5>
          </span>
          <hr />
          <span>
            <h4>Total</h4>
            <h4>{0}$</h4>
          </span>
          <hr />
          <button>PROCEED TO CHECKOUT</button>
        </div>
        <div className="code-promo">
          <p>if you have a promo code,Enter it here</p>
          <div className="promo-code-input">
            <input type="text" placeholder="promo code" />
            <button>Submit</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItems;
