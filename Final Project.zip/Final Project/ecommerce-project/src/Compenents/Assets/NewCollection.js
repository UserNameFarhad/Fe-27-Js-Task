import p9 from '../Assets/p9.avif'
import p25 from '../Assets/p25.avif'
import p18 from '../Assets/p18.jpg'
let NewCollection = [
    {
        id:9,
        name:"Seiko Sk 5 Sprts tmtc Wtch",
        newPrice:"89",
        oldPrice:"111",
        category:"men",
        image:p9,
    },
    {
        id:25,
        name:"VIVIENNE WESTWOOD Lady Sydenham Watch",
        newPrice:"68",
        oldPrice:"87",
        category:"women",
        image:p25,
    },
    {
        id:18,
        name:"Seiko Sk 5 Sprts tmtc Wtch",
        newPrice:"49",
        oldPrice:"87",
        category:"men",
        image:p18,
    },
]
export default NewCollection;