import blog1 from '../Assets/blog1.jpg'
import blog2 from '../Assets/blog2.jpg'
import blog3 from '../Assets/blog3.jpg'

let bloges = [
    {
        id:1,
        name:"What Curling Irons Are The Best Ones",
        date:"16 February 2020",
        img:blog1,
    },
    {
        id:2,
        name:"What Curling Irons Are The Best Ones",
        date:"12 Juin 2024",
        img:blog2,
    },
    {
        id:3,
        name:"What Curling Irons Are The Best Ones",
        date:"6 Mai 2022",
        img:blog3,
    },
    
];
export default bloges;