import React, { useState } from 'react'
import './Popular.css'
import data from "../Assets/data"
import Item from '../Item/Item'
const Popular = ({mode,setMode}) => {
const [popularLink,setPopularLink] = useState("bestSellers")

  return (
    <div className='popular'>
     <div className="popular-link">
        <h1 onClick={()=>setPopularLink("bestSellers")}  className={popularLink==="bestSellers"?"act-popular":""}>Best Sellers</h1>
        <h1 onClick={()=>setPopularLink("newArrivals")}  className={popularLink==="newArrivals"?"act-popular":""}>New Arrivals</h1>
        <h1 onClick={()=>setPopularLink("hotSales")} className={popularLink==="hotSales"?"act-popular":""}>Hot Sales</h1>
     </div>
     <div className="product-popular">
        {data.map((item,i)=>{
            if(item.category == popularLink){
                return <Item id={item.id} key={i} name={item.name} newPrice={item.newPrice} oldPrice={item.oldPrice} image={item.image}/>
            }
        })}
     </div>
    </div>
  )
}

export default Popular
