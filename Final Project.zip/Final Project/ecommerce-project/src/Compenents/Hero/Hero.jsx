import React, { useEffect, useState } from 'react'
import slid1 from '../Assets/slid1.png'
import slid2 from '../Assets/slid2.jpg'
import light_facebook from '../Assets/light_facebook.png'
import light_instagram from '../Assets/light_instagram.png'
import light_pintrest from '../Assets/light_pintrest.png'
import dark_facebook from '../Assets/dark_facebook.png'
import dark_instagram from '../Assets/dark_instagram.png'
import dark_pintrest from '../Assets/dark_pintrest.png'
import './Hero.css'
const Hero = ({mode,setMode}) => {
  let data = [
    {img:slid1,title1:"DISCOVER OUR",title2:" LATEST WATCHES"},
    {img:slid2,title1:"SHOP JEWELLERY FOR ",title2:"EVERY OCCASION"},
  ]
  const [index,setIndex] = useState(0)
  const [info,setInfo] = useState(data[index])
  return (
    <div className='hero'>
      <div className="hero-left">
        <h3>Shose Your Favorite Watches</h3>
        <h1>{info.title1}</h1>
        <h1>{info.title2}</h1>
        <p>Treat yourself or the lady in your life to a fabulous piece from our 
          extensive women's jewellery collection. Our diverse range of earrings 
           bracelets, rings, necklaces and charms spans the full fashion spectrum,
            from timeless classic pieces to contemporary, cutting-edge models. 
             With an impressive selection from some of the world's most iconic designers, </p>
        <button>Show Watches</button>
        <div className="social">
          <img src={mode==="dark"?light_facebook:dark_facebook} alt="" />
          <img src={mode==="dark"?light_instagram:dark_instagram} alt="" />
          <img src={mode==="dark"?light_pintrest:dark_pintrest} alt="" />
        </div>    
      </div>
      <div className="hero-right"><img src={info.img} alt="" /></div>
    </div>
  )
}

export default Hero
