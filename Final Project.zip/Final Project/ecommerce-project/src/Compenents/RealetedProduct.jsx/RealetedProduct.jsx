import React from 'react'
import newCollection from '../Assets/NewCollection'
import Item from '../Item/Item'
import './RealetedProduct.css'
const RealetedProduct = () => {
  return (
    <div className='realted'>
      <h1>Related Product   </h1>
      <div className="newCollection">
        {
            newCollection.map((item,i)=>{
                return <Item id={item.id} key={i} name={item.name} newPrice={item.newPrice} oldPrice={item.oldPrice} image={item.image} />
            })
        }
      </div>
    </div>
  )
}

export default RealetedProduct
