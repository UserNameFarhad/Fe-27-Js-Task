import React from "react";
import "./Item.css";
import { Link } from "react-router-dom";
const Item = ({ name, newPrice, oldPrice, image,id }) => {
  return (
    <div className='item'>
      <img src={image} alt='' />  
      <h2>{name}</h2>
      <div>
        <span>
          <h4>${newPrice}</h4>
          <h4 className='old'>${oldPrice}</h4>
        </span>
        <Link to={`/product/${id}`}><button onClick={window.scrollTo(0,0)} >Add To Cart</button></Link>
      </div>
    </div>
  );
};

export default Item;
