import React, { useState } from "react";
import "./Navbar.css";
import dark_logo from "../Assets/black_logo.png";
import light_logo from "../Assets/white_logo.png";
import dark_bar from "../Assets/dark_bar.png";
import white_bar from "../Assets/white_bar.png";
import dark_user from "../Assets/dark_user.png";
import white_user from "../Assets/white_user.png";
import summer_dark from "../Assets/Crescent.png";
import summer_white from "../Assets/sun.png";
import drakCart from "../Assets/cartShopping_dark.png";
import lightCart from "../Assets/cartShopping_light.png";
import { Link } from "react-router-dom";
const Navbar = ({ mode, setMode }) => {
  function theme() {
    if (mode === "light") {
      setMode("dark");
    } else {
      setMode("light");
    }
  }

  const [menu, setMenu] = useState("home");

  const [showMenu, setShowMenu] = useState("");

  function barClicked() {
    if (showMenu === "") {
      setShowMenu("show");
    } else {
      setShowMenu("");
    }
  }
  return (
    <nav>
      <a href='#' className='logo'><img src={mode === "light" ? dark_logo : light_logo}/></a>
      <img onClick={barClicked} src={mode === "light" ? dark_bar : white_bar} id='bars'/>
      <div className='all-icon-nav'>
        <div className={showMenu === "show" ? "show navbars" : "navbars"}>

          <div className='links'>
            <ul>
              <Link to='/'>
                <li onClick={() => setMenu("home")}>Home {menu === "home" ? <hr /> : <></>}</li>
              </Link>
              <Link to='/men'>
                <li onClick={() => setMenu("men")}>Men {menu === "men" ? <hr /> : <></>}</li>
              </Link>
              <Link to='/women'>
                <li onClick={() => setMenu("women")}>Women {menu === "women" ? <hr /> : <></>}</li>
              </Link>
              <Link to='/contact'>
                <li onClick={() => setMenu("contact")}>Contact {menu === "contact" ? <hr /> : <></>}</li>
              </Link>
            </ul>
          </div>
        </div>
        
        <div>
          <Link to='/login'>
            <img className='img' onClick={() => setMenu("")} src={mode === "light" ? dark_user : white_user}/>
          </Link>

          <img className='img' onClick={theme} src={mode === "light" ? summer_dark : summer_white}/>

          <span className='crt'>
            <Link to='/cart'>
              <img className='img cart' onClick={() => setMenu("")} src={mode === "light" ? drakCart : lightCart}/>
            </Link>
            <div className='crt-bt'></div>
          </span>
        </div>

      </div>
    </nav>
  );
};

export default Navbar;
