import React from 'react'
import './Blog.css'
import blog from '../Assets/Blog'
import BlogItem from '../BlogItem/BlogItem'
const Blog = () => {
  return (
    <div className='blog'>
      <h3>LATEST NEWS</h3>
      <h1>Watches New Trends</h1>
        <div className="blog-card">
        {blog.map((blog)=>{
            return <BlogItem name={blog.name} image={blog.img} date={blog.date} key={blog.id}/>
        })}
      </div>
      </div>
      
  )
}
export default Blog
