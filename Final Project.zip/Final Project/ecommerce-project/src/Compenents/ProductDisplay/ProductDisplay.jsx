import React, { useContext } from 'react'
import star_icon from '../Assets/star_icon.png'
import star_dolly_icon from '../Assets/star_dull_icon.png'
import './ProductDisplay.css'
import { ShopContext } from '../../Context/Context'
const ProductDisplay = (props) => {
    const {product} = props;
    const {addToCart} = useContext(ShopContext)
  return (
    <div className='display'>
        <div className="left-part">
            <div className="slide">
                <img src={product.image} className='main' alt="" />
            </div>
        </div>
        <div className="right-part">
            <h1>{product.name}</h1>
            <div className="star">
                <img src={star_icon} alt="" />
                <img src={star_icon} alt="" />
                <img src={star_icon} alt="" />
                <img src={star_icon} alt="" />
                <img src={star_dolly_icon} alt="" />
                <span>(125)</span>
            </div>
            <p className="desc-product">Lorem ipsum dolor sit amet consectetur adipisicing elit.Nobis pariatur corrupti illo sunt atque maiores nisi deleniti animi recusandae.</p>
            <div className="size">
                <h2>Select Size</h2>
                <ul>
                    <li>S</li>
                    <li>M</li>
                    <li>L</li>
                    <li>XL</li>
                    <li>XXL</li>
                </ul>
            </div>
            <button onClick={()=>{addToCart(product.id)}}>ADD TO CART</button>
            <div className="categ">
                <h4>category:<span>{product.category}-Watches</span></h4>
                <h4>Tags:<span>Modern,Latset</span></h4>
            </div>
        </div>
      
    </div>
  )
}

export default ProductDisplay
