import React, { useEffect, useRef, useState } from 'react'
import './Solde.css'
import soldeWatches from '../Assets/slid1.png'
const Solde = () => {
  const [timerDay,setTimerDay] = useState("00")
  const [timerHour,setTimerHour] = useState("00")
  const [timerMunites,setTimerMunites] = useState("00")
  const [timerSeconde,setTimerSeconde] = useState("00")
  let interval = useRef()
  const startTimer = () =>{
    const countDownDate = new Date("Julle 20 2024 00:00:00").getTime();
    interval = setInterval(()=>{
      const now = new Date().getTime();
      const distance = countDownDate - now;
      const days =Math.floor(distance / (1000*60*60*24)) ;
      const hour =Math.floor((distance % (1000*60*60*24) / (1000*60*60))) ;
      const munite =Math.floor((distance % (1000*60*60) / (1000*60))) ;
      const seconde =Math.floor((distance % (1000*60)) / 1000) ;
      if(distance < 0){
        clearInterval(interval.current)
      }else{
        setTimerDay(days)
        setTimerHour(hour)
        setTimerMunites(munite)
        setTimerSeconde(seconde)
      }
    },1000)
  }
  useEffect(()=>{
    startTimer();
    return()=>{
      clearInterval(interval.current)
    }
  },)
  return (
    <div className='solde'>
      <div className="sold">
        <div className="hedear">
            <h1>Watches Hot</h1>
            <h1 className='act'>Watches  Collection</h1>
            <h1>Accessories </h1>
        </div>
        <div className="image">
            <img src={soldeWatches} alt="" />
        </div>
        <div className="timer">
            <h3>DEAL OF THE WEEK</h3>
            <h1>Multi-pocket Chest
            Watches Black</h1>
            <div className="time">
                <span>
                    <h2>{timerDay<10?"0":""}{timerDay} :</h2>
                    <h4>Days</h4>
                </span>
                <span>
                    <h2>{timerHour<10?"0":""}{timerHour} :</h2>
                    <h4>Hours</h4>
                </span>
                <span>
                    <h2>{timerMunites<10?"0":""}{timerMunites} :</h2>
                    <h4>Minutes</h4>
                </span>
                <span>
                    <h2>{timerSeconde<10?"0":""}{timerSeconde}</h2>
                    <h4>Seconds</h4>
                </span>
            </div>
            <button>Shop Now</button>
        </div>
      </div>
    </div>
  )
}

export default Solde
