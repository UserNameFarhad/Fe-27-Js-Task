import React from 'react'
import './Brudcrams.css'
const Brudcrams = (props) => {
    const {product} = props
  return (
    <p> HOME - SHOP - {product.category} - {product.name}</p>
  )
}

export default Brudcrams
