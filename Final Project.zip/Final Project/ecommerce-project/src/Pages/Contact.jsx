import React from "react";
import "./CSS/contact.css";
const Contact = () => {
  return (
    <div className='contact'>
      <div className='contact-item'>
        <h1>Contact</h1>
        <input type='email' placeholder='Your Email' />
        <input type='text' placeholder='How Can We Help You?' className="message" />
        <input type='Submit' value={"submit"} />
      </div>
    </div>
  );
};

export default Contact;
