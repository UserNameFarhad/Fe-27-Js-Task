import React from 'react'
import CartItems from '../Compenents/CartItems/CartItems';

const Cart = ({mode}) => {
  return (
    <div>
      <CartItems mode={mode}/>
    </div>
  )
}

export default Cart;
