import React from 'react'

const CheckOut = () => {
  return (
    <div>
      
    </div>
  )
}

export default CheckOut
