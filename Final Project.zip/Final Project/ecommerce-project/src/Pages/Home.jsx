import React from 'react'
import Hero from '../Compenents/Hero/Hero'
import Popular from '../Compenents/Popular/Popular'
import Solde from '../Compenents/Solde/Solde'
import Blog from '../Compenents/Blog/Blog'

const Home = ({mode,setMode}) => {
  return (
    <div>
      <Hero mode={mode} setMode={setMode}/>
      <Popular mode={mode} setMode={setMode}/>
      <Solde/>
      <Blog/>
    </div>
  )
}

export default Home
