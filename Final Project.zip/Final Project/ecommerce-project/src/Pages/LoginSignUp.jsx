import React, { useState } from 'react'
import './CSS/LoginSignUp.css'
const LoginSignUp = () => {
  const [loginSignUp,setLoginSignUp] = useState("Register")
  return (
    <div className='login-signup'>
      <div className="signup-reges">
        <h1>{loginSignUp}</h1>
        <p>{loginSignUp} now and get full access to our app.</p>
        <form action="">
          {loginSignUp==="Register"?<span className='input-span'>
          <input type="text" placeholder='First Name' />
          <input type="text" placeholder='Last Name' />
          </span>:<></>}
           <br />
          <input type="email" placeholder='Email' /> <br />
          <input type="password" placeholder='Password' /> <br />
          {loginSignUp==="Register"?<input type="password" placeholder='Confirm Password' />:<></>}
          <input type="submit" value="Submit" /> <br />
          <p className='qution'>Already have an acount ? <span onClick={loginSignUp==="Register"?()=>{setLoginSignUp("Login")}:()=>{setLoginSignUp("Register")}}>{loginSignUp==="Register"?"Signin":"Register now"}</span></p>
        </form>
      </div>
    </div>
  )
}

export default LoginSignUp
