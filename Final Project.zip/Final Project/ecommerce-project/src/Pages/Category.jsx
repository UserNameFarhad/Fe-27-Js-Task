import React, { useContext } from "react";
import "./CSS/Category.css";
import { ShopContext } from "../Context/Context";
import Item from "../Compenents/Item/Item";
const Category = (props) => {
  const { all_product } = useContext(ShopContext);
  return (
    <div className='category'>
      <div className='info-category'>
        <p className='link-category'>
          Home - <b className='category-link-active'>{props.category}</b>
        </p>
        <h1>{props.category} JEWELLERY | WATCHSHOP</h1>
        <p className='description'>
          Treat yourself or the lady in your life to a fabulous piece from our
          extensive women's jewellery collection. Our diverse range of earrings,
          bracelets, rings, necklaces and charms spans the full fashion
          spectrum, from timeless classic pieces to contemporary, cutting-edge
          models. With an impressive selection from some of the world's most
          iconic designers, including Guess, Olivia Burton, THOMAS SABO and
          BOSS, you can look good whether you're at work or out with friends.
          Explore our collections and find your new favourite accessory.
        </p>
      </div>
      <div className='category-product'>
        <div className='product'>
          {all_product.map((item,i) => {
            if (item.category === props.category) {
              return (
                <Item
                  key={i}
                  id={item.id}
                  name={item.name}
                  newPrice={item.newPrice}
                  oldPrice={item.oldPrice}
                  image={item.image}
                />
              );
            } else {
              return null;
            }
          })}
        </div>
      </div>
    </div>
  );
};

export default Category;
