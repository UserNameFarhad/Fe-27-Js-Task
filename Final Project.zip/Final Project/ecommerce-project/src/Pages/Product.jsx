import React, { useContext } from 'react'
import { ShopContext } from '../Context/Context'
import { useParams } from 'react-router-dom'
import Brudcrams from '../Compenents/Brudcrams/Brudcrams'
import ProductDisplay from '../Compenents/ProductDisplay/ProductDisplay'
import './CSS/Product.css'
import Description from '../Compenents/Description/Description'
import RealetedProduct from '../Compenents/RealetedProduct.jsx/RealetedProduct'
const Product = () => {
  const {all_product} = useContext(ShopContext)
  const {productId} = useParams()
  const product = all_product.find((e)=>e.id === Number(productId))
  return (
    <div className='product'>
      <Brudcrams product={product}/> 
      <ProductDisplay product={product}/> 
      <Description/>
      <RealetedProduct/>
    </div>
  )
}

export default Product
