import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./Compenents/Navbar/Navbar";
import { useState } from "react";
import Home from "./Pages/Home";
import LoginSignUp from "./Pages/LoginSignUp";
import Category from "./Pages/Category";
import Product from "./Pages/Product";
import Footer from "./Compenents/Footer/Footer";
import Cart from "./Pages/Cart";
import Contact from "./Pages/Contact"
import CheckOut from "./Pages/CheckOut";
function App() {
  const [mode, setMode] = useState("dark");
  return (
    <div className={mode === "light" ? " container" : "dark container"}>
      <BrowserRouter>
        <Navbar mode={mode} setMode={setMode} />
        <Routes>
          <Route path='/' element={<Home mode={mode} setMode={setMode} />} />
          <Route path='/login' element={<LoginSignUp />} />
          <Route path='/men' element={<Category category='men' />} />
          <Route path='/women' element={<Category category='women' />} />
          <Route path='/product' element={<Product />}>
            <Route path=':productId' element={<Product />} />
          </Route>
          <Route path="/cart" element={<Cart mode={mode}/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/checkout" element={<CheckOut/>}/>
        </Routes>
        <Footer mode={mode}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
