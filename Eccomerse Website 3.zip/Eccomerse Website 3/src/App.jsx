import React from 'react'

const App = () => {
  return (
    <main className='app'></main>
  )
}

export default App